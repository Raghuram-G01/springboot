package com.raghu.hello.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class WelcomeController {
    @GetMapping("/welcome")
    public String showWelcomePage(Model model){
        model.addAttribute("message","Welcome to Spring Boot Application");
        // Now it correctly points to "hello.html"
        return "hello"; 
    }
}